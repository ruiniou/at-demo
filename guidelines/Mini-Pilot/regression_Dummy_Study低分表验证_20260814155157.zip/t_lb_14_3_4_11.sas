%let suffix=saf;

proc format;
    value trtfmtc
        1 = "AZD999(*ESC*)n1 mg/kg"
        2 = "AZD999(*ESC*)n2 mg/kg"
        3 = "AZD999(*ESC*)nTotal"
        4 = "Investigator choice of therapy"
        5 = "Total"
    ;
    value $shift3f (notsorted)
        1 = "Low"
        2 = "Normal"
        3 = "High"
    ;
run;

%m_u_popn(
    inds=adam.adsl
    ,pop_flag=SAFFL = "Y"
    ,trtgrpn=TRT01AN
    ,trtfmtC=trtfmtc
    ,trtlev=1|2|1 2|3|1 2 3
    ,UniqueIDVars=USUBJID
    ,gmacro=safpop
    ,BigN=Y
    ,nformat=
    ,deBug=N
);

/*@block Haematology shift from baseline to worst on-treatment value */
proc sort data=adam.adsl(keep=USUBJID SAFFL TRT01AN where=(SAFFL = "Y" and not missing(TRT01AN)))
          out=adsl_saf;
    by USUBJID;
run;

proc sort data=adam.adlb(keep=USUBJID PARAM PARAMCD PARCAT1 ABLFL ONTRTFL ANL08FL ANL10FL BTOXGR ATOXGR BNRIND ANRIND)
          out=adlb0;
    by USUBJID PARAM PARAMCD;
    where PARCAT1 = "HEMATOLOGY" and not missing(PARAMCD);
run;

data adlb1;
    merge adlb0(in=a) adsl_saf(in=b);
    by USUBJID;
    if a and b;
run;

proc sort data=adlb1; by PARAM PARAMCD USUBJID; run;

data adlb_base_ctc(keep=USUBJID PARAM PARAMCD TRT01AN SAFFL base_cat)
     adlb_wrst_ctc(keep=USUBJID PARAM PARAMCD TRT01AN SAFFL worst_cat)
     adlb_base_ref(keep=USUBJID PARAM PARAMCD TRT01AN SAFFL base_cat)
     adlb_wrst_ref(keep=USUBJID PARAM PARAMCD TRT01AN SAFFL worst_cat);
    set adlb1;
    length base_cat worst_cat $20;

    if ABLFL = "Y" and not missing(BTOXGR) then do;
        base_cat = propcase(lowcase(strip(BTOXGR)));
        if base_cat in ("Low","Normal","High") then output adlb_base_ctc;
    end;
    if ONTRTFL = "Y" and ANL08FL = "Y" and not missing(ATOXGR) then do;
        worst_cat = propcase(lowcase(strip(ATOXGR)));
        if worst_cat in ("Low","Normal","High") then output adlb_wrst_ctc;
    end;

    if ABLFL = "Y" and missing(BTOXGR) and not missing(BNRIND) then do;
        base_cat = propcase(lowcase(strip(BNRIND)));
        if base_cat in ("Low","Normal","High") then output adlb_base_ref;
    end;
    if ONTRTFL = "Y" and ANL10FL = "Y" and missing(ATOXGR) and not missing(ANRIND) then do;
        worst_cat = propcase(lowcase(strip(ANRIND)));
        if worst_cat in ("Low","Normal","High") then output adlb_wrst_ref;
    end;
run;

proc sort data=adlb_base_ctc; by PARAM PARAMCD USUBJID; run;
proc sort data=adlb_wrst_ctc; by PARAM PARAMCD USUBJID; run;
proc sort data=adlb_base_ref; by PARAM PARAMCD USUBJID; run;
proc sort data=adlb_wrst_ref; by PARAM PARAMCD USUBJID; run;

data shift_ctc;
    merge adlb_base_ctc(in=b) adlb_wrst_ctc(in=w);
    by PARAM PARAMCD USUBJID;
    if b and w;
run;

data shift_ref;
    merge adlb_base_ref(in=b) adlb_wrst_ref(in=w);
    by PARAM PARAMCD USUBJID;
    if b and w;
run;

data shift_in;
    set shift_ctc shift_ref;
    length PARAM_PAGE $200;
    PARAM_PAGE = strip(PARAM);
run;

proc sort data=shift_in; by PARAM PARAMCD TRT01AN USUBJID; run;

%macro build_one_trt(trt_where=, trt_idx=, grp_label=);
    %m_t_lb_shift(
        inds=shift_in
        ,pop_flag=SAFFL = "Y"
        ,whr=%nrstr((&trt_where))
        ,paramVar=PARAM_PAGE
        ,paramVarN=
        ,paramvarfmt=
        ,pop_mvar=safpop
        ,trtgrpn=TRT01AN
        ,trtTot=N
        ,UniqueIDVars=USUBJID
        ,BigN0=Y
        ,Nobs0=Y
        ,rowvarc=base_cat
        ,rowfmt=$shift3f
        ,rowTot=N
        ,colvarc=worst_cat
        ,colfmt=$shift3f
        ,colTot=N
        ,lenlist=20#8#10#10#10#10
        ,headerlist=Group#Nobs#Baseline
        ,above_header=Worst on-treatment value
        ,pg=999
        ,pg_byvar=Y
        ,sfx=tmp&trt_idx
        ,reportout=N
        ,deBug=N
    );

    data tmpout2_&trt_idx;
        set final2output;
        length PARAM $200 GROUP $200 NOBS $20 BASELINE $20 LOW NORMAL HIGH $20;
        PARAM = col0;
        if missing(col3) then do;
            GROUP = "&grp_label";
            NOBS = col2;
            BASELINE = "";
            LOW = "";
            NORMAL = "";
            HIGH = "";
            roword = 0;
            output;
        end;
        else do;
            GROUP = "";
            NOBS = "";
            BASELINE = col3;
            LOW = col4;
            NORMAL = col5;
            HIGH = col6;
            select (strip(BASELINE));
                when ("Low") roword = 1;
                when ("Normal") roword = 2;
                when ("High") roword = 3;
                otherwise roword = 9;
            end;
            output;
        end;
        keep PARAM GROUP NOBS BASELINE LOW NORMAL HIGH roword;
    run;
%mend;

%build_one_trt(trt_where=TRT01AN = 1, trt_idx=1, grp_label=%nrstr(AZD999(*ESC*)n1 mg/kg(*ESC*)nN=&safpopBigN1));
%build_one_trt(trt_where=TRT01AN = 2, trt_idx=2, grp_label=%nrstr(AZD999(*ESC*)n2 mg/kg(*ESC*)nN=&safpopBigN2));
%build_one_trt(trt_where=TRT01AN in (1,2), trt_idx=3, grp_label=%nrstr(AZD999(*ESC*)nTotal(*ESC*)nN=&safpopBigN3));
%build_one_trt(trt_where=TRT01AN = 3, trt_idx=4, grp_label=%nrstr(Investigator choice of therapy(*ESC*)nN=&safpopBigN4));
%build_one_trt(trt_where=TRT01AN in (1,2,3), trt_idx=5, grp_label=%nrstr(Total(*ESC*)nN=&safpopBigN5));

proc sort data=tmpout2_1; by PARAM roword; run;
proc sort data=tmpout2_2; by PARAM roword; run;
proc sort data=tmpout2_3; by PARAM roword; run;
proc sort data=tmpout2_4; by PARAM roword; run;
proc sort data=tmpout2_5; by PARAM roword; run;

data final2output;
    set tmpout2_1(in=a)
        tmpout2_2(in=b)
        tmpout2_3(in=c)
        tmpout2_4(in=d)
        tmpout2_5(in=e);
    by PARAM;
    length col0 $200 col1 $200 col2-col6 $20;
    retain grpseq 0;
    if first.PARAM then grpseq = 0;
    if roword = 0 then grpseq + 1;
    col0 = PARAM;
    col1 = GROUP;
    col2 = NOBS;
    col3 = BASELINE;
    col4 = LOW;
    col5 = NORMAL;
    col6 = HIGH;
    blank_seq = grpseq;
    label col1 = 'Group'
          col2 = 'Nobs'
          col3 = 'Baseline'
          col4 = 'Low(*ESC*)nn (%)'
          col5 = 'Normal(*ESC*)nn (%)'
          col6 = 'High(*ESC*)nn (%)';
    keep col0 col1 col2 col3 col4 col5 col6 blank_seq;
run;

proc sql noprint;
    select value into: __oufile
    from tlf.titles
    where upcase(program) = "%upcase(%scan(&_exec_programname., 1, '.'))"
      and upcase(suffix)  = "%upcase(&suffix.)"
      and parm = "OUTFILE";
quit;

data final2qc;
    set final2output;
    keep col:;
run;

data tlf.&__oufile.;
    set final2qc;
run;

%istartv2(suffix=&suffix.);
options nobyline;

%m_u_report(
    table=final2output
    ,lenlist=24#8#10#10#10#10
    ,justlist=l#c#l#c#c#c
    ,justlist_header=l#c#l#c#c#c
    ,nolblist=N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N
    ,idlist=Y#Y#Y
    ,idpage=N#N#N#N#N#N
    ,defcol=col1 col2 col3 ("Worst on-treatment value" col4 col5 col6)
    ,blank_after=blank_seq
    ,pg=999
    ,pg_byvar=Y
);

%istopv2;