%let suffix=itt3l_base;

proc format;
    value _t14192trt
        1 = 'AZD999(*ESC*)n1 mg/kg'
        2 = 'AZD999(*ESC*)n2 mg/kg'
        3 = 'AZD999(*ESC*)nTotal'
        4 = 'Investigator choice of therapy'
        5 = 'Total'
    ;

    value $overclas_cat (notsorted)
        'Metastatic' = 'Metastatic'
        'Locally advanced' = 'Locally advanced'
        'Both metastatic and locally advance' = 'Both metastatic and locally advance'
        'No evidence of disease' = 'No evidence of disease'
        ' ' = 'Missing'
    ;

    value $ptumloc_cat (notsorted)
        'Esophagus' = 'Esophagus'
        'Stomach' = 'Stomach'
        'Gastroesophageal junction' = 'Gastroesophageal junction'
        'Other' = 'Other'
        ' ' = 'Missing'
    ;

    value $whsttyp_cat (notsorted)
        'Adenocarcinoma (NOS)' = 'Adenocarcinoma (NOS)'
        'Signet Ring Cell Carcinoma' = 'Signet Ring Cell Carcinoma'
        'Papillary Adenocarcinoma' = 'Papillary Adenocarcinoma'
        'Tubular Adenocarcinoma' = 'Tubular Adenocarcinoma'
        'Mucinous Adenocarcinoma' = 'Mucinous Adenocarcinoma'
        'Mixed Adenocarcinoma' = 'Mixed Adenocarcinoma'
        'Other' = 'Other'
        ' ' = 'Missing'
    ;

    value $laurcls_cat (notsorted)
        'Adenocarcinoma, Intestinal Type' = 'Adenocarcinoma, Intestinal Type'
        'Adenocarcinoma, Diffuse Type' = 'Adenocarcinoma, Diffuse Type'
        'Adenocarcinoma, Mixed Type' = 'Adenocarcinoma, Mixed Type'
        'Unknown' = 'Unknown'
        ' ' = 'Missing'
    ;

    value $tumgrade_cat (notsorted)
        'Well differentiated (G1)' = 'Well differentiated (G1)'
        'Moderately differentiated (G2)' = 'Moderately differentiated (G2)'
        'Poorly differentiated (G3)' = 'Poorly differentiated (G3)'
        'Unassessable (GX)' = 'Unassessable (GX)'
        ' ' = 'Missing'
    ;

    value $livermet_cat (notsorted)
        'Yes' = 'Yes'
        'No' = 'No'
    ;

    value $perimet_cat (notsorted)
        'Yes' = 'Yes'
        'No' = 'No'
    ;

    value $oncrsrl_cat (notsorted)
        'Complete response' = 'Complete response'
        'Partial response' = 'Partial response'
        'Stable disease' = 'Stable disease'
        'Progressive disease' = 'Progressive disease'
        'Not evaluable' = 'Not evaluable'
        'Not applicable' = 'Not applicable'
        ' ' = 'Missing'
    ;

    value $cldn1_cat (notsorted)
        '<25% at >=1+ intensity' = '< 25% at 1+ intensity'
        '>=25% - <50% at >= 1+ intensity' = '>=25% - <50% at 1+ intensity'
        '>=50% - <75% at >= 1+ intensity' = '>=50% - <75% at 1+ intensity'
        '>=75% at >= 1+ intensity' = '>=75% at 1+ intensity'
        ' ' = 'Missing'
    ;

    value $cldn2_cat (notsorted)
        '<25% at >= 2+ intensity' = '< 25% at 2+ intensity'
        '>=25% - <50% at >= 2+ intensity' = '>=25% - <50% at 2+ intensity'
        '>=50% - <75% at >= 2+ intensity' = '>=50% - <75% at 2+ intensity'
        '>=75% at >= 2+ intensity' = '>=75% at 2+ intensity'
        ' ' = 'Missing'
    ;

    value $itlblfl_cat (notsorted)
        'Y' = 'Yes'
        'N' = 'No'
        ' ' = 'Missing'
    ;
run;

%m_u_popn(
    inds=adam.adsl,
    pop_flag=ITT3LFL='Y',
    trtgrpn=TRT01PN,
    trtfmtC=_t14192trt,
    trtlev=1|2|1 2|3|1 2 3,
    UniqueIDVars=USUBJID,
    gmacro=itt3lpopb,
    BigN=Y,
    nformat=
);

/*@block Disease characteristics at screening */
%m_t_dm(
    inds=adam.adsl,
    pop_flag=ITT3LFL='Y',
    whr=ITT3LFL='Y',
    trtgrpn=TRT01PN,
    pop_mvar=itt3lpopb,
    varlist_cat=OVERCLAS PTUMLOC WHSTTYP LAURCLS TUMGRADE LIVERMET PERIMET ONCRSRL CLDN1 CLDN2 ITLBLFL,
    varlist_cont=IDXRANDM,
    decimal_list=0,
    output_order=IDXRANDM OVERCLAS PTUMLOC WHSTTYP LAURCLS TUMGRADE LIVERMET PERIMET ONCRSRL CLDN1 CLDN2 ITLBLFL,
    formatlist=format OVERCLAS $overclas_cat. PTUMLOC $ptumloc_cat. WHSTTYP $whsttyp_cat. LAURCLS $laurcls_cat. TUMGRADE $tumgrade_cat. LIVERMET $livermet_cat. PERIMET $perimet_cat. ONCRSRL $oncrsrl_cat. CLDN1 $cldn1_cat. CLDN2 $cldn2_cat. ITLBLFL $itlblfl_cat.,
    labellist=label IDXRANDM='Time from diagnosis to randomisation (months)' OVERCLAS='Overall disease classification [a]' PTUMLOC='Primary tumour location' WHSTTYP='WHO Classification' LAURCLS='Lauren Classification' TUMGRADE='Tumour grade' LIVERMET='Liver metastasis' PERIMET='Peritoneal metastasis' ONCRSRL='Best response to last prior systemic cancer therapy' CLDN1='CLDN 18.2 1+ Intensity' CLDN2='CLDN 18.2 2+ Intensity' ITLBLFL='Measurable disease',
    exclude_stat=con_mis con_Q1 con_Q3 con_Sum cat_n,
    add_lead_row=Y,
    lenlist=34#16#10#10#10#14#10,
    justlist=l#l#c#c#c#c#c,
    justlist_header=l#l#c#c#c#c#c,
    nolblist=Y#N#N#N#N#N#N,
    orderlist=Y#N#N#N#N#N#N,
    defcol=,
    pg=18,
    sfx=&suffix.,
    reportout=Y,
    deBug=N
);