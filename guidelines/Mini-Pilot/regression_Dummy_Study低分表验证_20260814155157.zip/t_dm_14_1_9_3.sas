%let suffix=base_itt;

proc format;
    value _t14193_trt
        1 = 'AZD999(*ESC*)n1 mg/kg'
        2 = 'AZD999(*ESC*)n2 mg/kg'
        3 = 'AZD999(*ESC*)nTotal'
        4 = 'Investigator choice of therapy'
        5 = 'Total'
    ;
    value $idxrandm_cat (notsorted)
        '<= 6 months' = '<= 6 months'
        '< 6 months and <= 12 months' = '< 6 months and <= 12 months'
        '> 12 months' = '> 12 months'
        'Missing' = 'Missing'
    ;
    value $tnmnn_cat (notsorted)
        'NX' = 'NX'
        'N0' = 'N0'
        'N1' = 'N1'
        'N2' = 'N2'
        'N3' = 'N3'
        'N3A' = 'N3a'
        'N3B' = 'N3b'
        'Missing' = 'Missing'
    ;
    value $overclas_cat (notsorted)
        'Metastatic' = 'Metastatic'
        'Locally advanced' = 'Locally advanced'
        'Both metastatic and locally advance' = 'Both metastatic and locally advance'
        'No evidence of disease' = 'No evidence of disease'
        'Missing' = 'Missing'
    ;
    value $ptumloc_cat (notsorted)
        'Esophagus' = 'Esophagus'
        'Stomach' = 'Stomach'
        'Gastroesophageal junction' = 'Gastroesophageal junction'
        'Other' = 'Other'
        'Missing' = 'Missing'
    ;
    value $whsttyp_cat (notsorted)
        'Adenocarcinoma (NOS)' = 'Adenocarcinoma (NOS)'
        'Signet Ring Cell Carcinoma' = 'Signet Ring Cell Carcinoma'
        'Papillary Adenocarcinoma' = 'Papillary Adenocarcinoma'
        'Tubular Adenocarcinoma' = 'Tubular Adenocarcinoma'
        'Mucinous Adenocarcinoma' = 'Mucinous Adenocarcinoma'
        'Mixed Adenocarcinoma' = 'Mixed Adenocarcinoma'
        'Other' = 'Other'
        'Missing' = 'Missing'
    ;
    value $laurcls_cat (notsorted)
        'Adenocarcinoma, Intestinal Type' = 'Adenocarcinoma, Intestinal Type'
        'Adenocarcinoma, Diffuse Type' = 'Adenocarcinoma, Diffuse Type'
        'Adenocarcinoma, Mixed Type' = 'Adenocarcinoma, Mixed Type'
        'Unknown' = 'Unknown'
        'Missing' = 'Missing'
    ;
    value $tumgrade_cat (notsorted)
        'Well differentiated (G1)' = 'Well differentiated (G1)'
        'Moderately differentiated (G2)' = 'Moderately differentiated (G2)'
        'Poorly differentiated (G3)' = 'Poorly differentiated (G3)'
        'Unassessable (GX)' = 'Unassessable (GX)'
        'Missing' = 'Missing'
    ;
    value $yesno_cat (notsorted)
        'Yes' = 'Yes'
        'No' = 'No'
    ;
    value $oncrsrl_cat (notsorted)
        'Complete response' = 'Complete response'
        'Partial response' = 'Partial response'
        'Stable disease' = 'Stable disease'
        'Progressive disease' = 'Progressive disease'
        'Not evaluable' = 'Not evaluable'
        'Not applicable' = 'Not applicable'
        'Missing' = 'Missing'
    ;
    value $cldn1_cat (notsorted)
        '<25% at >=1+ intensity' = '< 25% at 1+ intensity'
        '>=25% - <50% at >= 1+ intensity' = '>=25% - <50% at 1+ intensity'
        '>=50% - <75% at >= 1+ intensity' = '>=50% - <75% at 1+ intensity'
        '>=75% at >= 1+ intensity' = '>=75% at 1+ intensity'
        'Missing' = 'Missing'
    ;
    value $cldn2_cat (notsorted)
        '<25% at >= 2+ intensity' = '< 25% at 2+ intensity'
        '>=25% - <50% at >= 2+ intensity' = '>=25% - <50% at 2+ intensity'
        '>=50% - <75% at >= 2+ intensity' = '>=50% - <75% at 2+ intensity'
        '>=75% at >= 2+ intensity' = '>=75% at 2+ intensity'
        'Missing' = 'Missing'
    ;
    value $measd_cat (notsorted)
        'Y' = 'Yes'
        'N' = 'No'
    ;
    value $metsite_cat (notsorted)
        'ANY SITE' = 'Any site'
        'ADRENAL GLAND' = 'Adrenal gland'
        'BLADDER' = 'Bladder'
        'BONE' = 'Bone'
        'BRAIN' = 'Brain'
        'DISTANT LYMPH NODE' = 'Distant lymph node'
        'GENITOURINARY SYSTEM' = 'Genitourinary system'
        'KIDNEY' = 'Kidney'
        'LIVER' = 'Liver'
        'LUNG' = 'Lung'
        'NECK' = 'Neck'
        'OMENTUM' = 'Omentum'
        'PANCREAS' = 'Pancreas'
        'PELVIS' = 'Pelvis'
        'PERICARDIAL EFFUSION' = 'Pericardial effusion'
        'PERITONEAL CAVITY' = 'Peritoneal cavity'
        'PERITONEUM' = 'Peritoneum'
        'PLEURA' = 'Pleura'
        'PLEURAL EFFUSION' = 'Pleural effusion'
        'REGIONAL LYMPH NODE' = 'Regional lymph node'
        'SOFT TISSUE' = 'Soft tissue'
        'SPLEEN' = 'Spleen'
        'OTHER' = 'Other metastatic sites'
        'Missing' = 'Missing'
    ;
run;

%m_u_popn(
    inds=adam.adsl
    ,pop_flag=ITTFL='Y' and TRT01PN in (1,2,3)
    ,trtgrpn=TRT01PN
    ,trtfmtC=_t14193_trt
    ,trtlev=1|2|1 2|3|1 2 3
    ,UniqueIDVars=USUBJID
    ,gmacro=ittbase
    ,BigN=Y
    ,nformat=
    ,deBug=N
);

data adsl_base;
    set adam.adsl;
    where ittfl='Y' and trt01pn in (1,2,3);
    length idxrandm_grp $32 overclas_c ptumloc_c whsttyp_c laurcls_c tumgrade_c $200
           livermet_c perimet_c oncrsrl_c cldn1_c cldn2_c measd_c $80;

    if missing(idxrandm) then idxrandm_grp='Missing';
    else if idxrandm <= 6 then idxrandm_grp='<= 6 months';
    else if idxrandm <= 12 then idxrandm_grp='< 6 months and <= 12 months';
    else if idxrandm > 12 then idxrandm_grp='> 12 months';

    overclas_c = coalescec(strip(overclas),'Missing');
    ptumloc_c  = coalescec(strip(ptumloc),'Missing');
    whsttyp_c  = coalescec(strip(whsttyp),'Missing');
    laurcls_c  = coalescec(strip(laurcls),'Missing');
    tumgrade_c = coalescec(strip(tumgrade),'Missing');
    oncrsrl_c  = coalescec(strip(oncrsrl),'Missing');
    cldn1_c    = coalescec(strip(cldn1),'Missing');
    cldn2_c    = coalescec(strip(cldn2),'Missing');

    if missing(livermet) then livermet_c='No';
    else livermet_c=strip(livermet);

    if missing(perimet) then perimet_c='No';
    else perimet_c=strip(perimet);

    if missing(itlblfl) then measd_c='N';
    else measd_c=strip(itlblfl);

    keep usubjid trt01pn idxrandm idxrandm_grp overclas_c ptumloc_c whsttyp_c laurcls_c tumgrade_c
         livermet_c perimet_c oncrsrl_c cldn1_c cldn2_c measd_c;
run;

proc sort data=adam.adfa(
        where=(param='TNM Classification- Regional Lymph Nodes'
               and parcat1='TUMOR PATHOLOGY'
               and parcat2='PATHOLOGY AT SCREENING'))
        out=adfa_tnm_raw(keep=usubjid avalc);
    by usubjid;
run;

proc sort data=adfa_tnm_raw nodupkey;
    by usubjid;
run;

proc sort data=adsl_base(keep=usubjid trt01pn) out=adsl_tnm_denom;
    by usubjid;
run;

data adfa_tnm_subject;
    merge adsl_tnm_denom(in=a)
          adfa_tnm_raw(in=b rename=(avalc=tnmnn));
    by usubjid;
    if a;
    length tnmnn $8;
    if missing(tnmnn) then tnmnn='Missing';
run;

proc sort data=adsl_base(keep=usubjid trt01pn overclas_c) out=adsl_met_denom;
    by usubjid;
run;

data adsl_met_pop;
    set adsl_met_denom;
    where overclas_c in ('Metastatic','Both metastatic and locally advance');
run;

proc sort data=adam.adfa(
        where=(param='Tumor Extent' and parcat1='Extent of Disease (Oncology)'))
        out=adfa_met_raw(keep=usubjid faloc);
    by usubjid;
run;

data adfa_met_detail adfa_met_missing;
    merge adsl_met_pop(in=b)
          adfa_met_raw(in=a);
    by usubjid;
    length metsite $40;
    if not b then delete;

    if a then do;
        metsite='ANY SITE'; output adfa_met_detail;
        if not missing(faloc) then do;
            if upcase(strip(faloc)) in (
                'ADRENAL GLAND','BLADDER','BONE','BRAIN','DISTANT LYMPH NODE','GENITOURINARY SYSTEM',
                'KIDNEY','LIVER','LUNG','NECK','OMENTUM','PANCREAS','PELVIS','PERICARDIAL EFFUSION',
                'PERITONEAL CAVITY','PERITONEUM','PLEURA','PLEURAL EFFUSION','REGIONAL LYMPH NODE',
                'SOFT TISSUE','SPLEEN'
            ) then metsite=upcase(strip(faloc));
            else metsite='OTHER';
            output adfa_met_detail;
        end;
        else do;
            metsite='Missing';
            output adfa_met_missing;
        end;
    end;
    else do;
        metsite='Missing';
        output adfa_met_missing;
    end;
    keep usubjid trt01pn metsite;
run;

data adfa_met_site;
    set adfa_met_detail adfa_met_missing;
run;

proc sort data=adfa_met_site nodupkey;
    by usubjid trt01pn metsite;
run;

proc sort data=adsl_base; by usubjid; run;
proc sort data=adfa_tnm_subject; by usubjid; run;
proc sort data=adsl_met_pop; by usubjid; run;

/*@block Continuous disease characteristic */
%m_t_dm(
    inds=adsl_base
    ,whr=trt01pn in (1,2,3)
    ,pop_flag=1
    ,trtgrpn=trt01pn
    ,pop_mvar=ittbase
    ,varlist_cat=
    ,varlist_cont=idxrandm
    ,decimal_list=0
    ,output_order=idxrandm
    ,formatlist=
    ,labellist=label idxrandm='Time from diagnosis to randomisation (months)'
    ,exclude_stat=con_mis con_q1 con_q3 con_sum cat_n
    ,add_lead_row=Y
    ,hide_lvls=N
    ,lenlist=34#10#11#11#11#11#11
    ,justlist=l#l#c#c#c#c#c
    ,justlist_header=l#l#c#c#c#c#c
    ,nolblist=Y#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N
    ,pg=999
    ,sfx=&suffix._b1
    ,reportout=N
    ,deBug=N
);

data blk_cont;
    set final2output;
    blank_var=1;
    ord1=blank_var*1000+ord1;
run;

/*@block Categorical disease characteristics */
%m_t_dm(
    inds=adfa_tnm_subject
    ,whr=trt01pn in (1,2,3)
    ,pop_flag=1
    ,trtgrpn=trt01pn
    ,pop_mvar=ittbase
    ,varlist_cat=tnmnn
    ,varlist_cont=
    ,output_order=tnmnn
    ,formatlist=format tnmnn $tnmnn_cat.
    ,labellist=label tnmnn='TNM Classification- Regional Lymph Nodes'
    ,exclude_stat=cat_n
    ,add_lead_row=Y
    ,hide_lvls=N
    ,lenlist=34#10#11#11#11#11#11
    ,justlist=l#l#c#c#c#c#c
    ,justlist_header=l#l#c#c#c#c#c
    ,nolblist=Y#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N
    ,pg=999
    ,sfx=&suffix._b2a
    ,reportout=N
    ,deBug=N
);

data blk_cat_01;
    set final2output;
    blank_var=2;
    ord1=blank_var*1000+ord1;
run;

%m_t_dm(
    inds=adsl_base
    ,whr=trt01pn in (1,2,3)
    ,pop_flag=1
    ,trtgrpn=trt01pn
    ,pop_mvar=ittbase
    ,varlist_cat=idxrandm_grp overclas_c ptumloc_c whsttyp_c laurcls_c tumgrade_c livermet_c perimet_c oncrsrl_c cldn1_c cldn2_c measd_c
    ,varlist_cont=
    ,output_order=idxrandm_grp overclas_c ptumloc_c whsttyp_c laurcls_c tumgrade_c livermet_c perimet_c oncrsrl_c cldn1_c cldn2_c measd_c
    ,formatlist=format idxrandm_grp $idxrandm_cat. overclas_c $overclas_cat. ptumloc_c $ptumloc_cat. whsttyp_c $whsttyp_cat. laurcls_c $laurcls_cat. tumgrade_c $tumgrade_cat. livermet_c $yesno_cat. perimet_c $yesno_cat. oncrsrl_c $oncrsrl_cat. cldn1_c $cldn1_cat. cldn2_c $cldn2_cat. measd_c $measd_cat.
    ,labellist=label idxrandm_grp='Time from diagnosis to randomisation Months' overclas_c='Overall disease classification [a]' ptumloc_c='Primary tumour location' whsttyp_c='WHO Classification' laurcls_c='Lauren Classification' tumgrade_c='Tumour grade' livermet_c='Liver metastasis' perimet_c='Peritoneal metastasis' oncrsrl_c='Best response to last prior systemic cancer therapy' cldn1_c='CLDN 18.2' cldn2_c='CLDN 18.2' measd_c='Measurable disease'
    ,exclude_stat=cat_n
    ,add_lead_row=Y
    ,hide_lvls=N
    ,lenlist=34#10#11#11#11#11#11
    ,justlist=l#l#c#c#c#c#c
    ,justlist_header=l#l#c#c#c#c#c
    ,nolblist=Y#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N
    ,pg=999
    ,sfx=&suffix._b2b
    ,reportout=N
    ,deBug=N
);

data blk_cat_02;
    set final2output;
    blank_var=3;
    ord1=blank_var*1000+ord1;
    if xx_variable='cldn2_c' and strip(col1)='CLDN 18.2' then col1='';
run;

/*@block Metastatic sites */
%m_t_dm(
    inds=adfa_met_site
    ,whr=trt01pn in (1,2,3)
    ,pop_flag=1
    ,trtgrpn=trt01pn
    ,pop_mvar=ittbase
    ,varlist_cat=metsite
    ,varlist_cont=
    ,output_order=metsite
    ,formatlist=format metsite $metsite_cat.
    ,labellist=label metsite='Metastatic [b]'
    ,exclude_stat=cat_n
    ,add_lead_row=Y
    ,denom_dt=adsl_met_pop
    ,nodup_by=usubjid trt01pn metsite
    ,hide_lvls=N
    ,lenlist=34#10#11#11#11#11#11
    ,justlist=l#l#c#c#c#c#c
    ,justlist_header=l#l#c#c#c#c#c
    ,nolblist=Y#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N
    ,pg=999
    ,sfx=&suffix._b3
    ,reportout=N
    ,deBug=N
);

data blk_met;
    set final2output;
    blank_var=4;
    ord1=blank_var*1000+ord1;
run;

/*@block Assemble and report */
data final2output;
    length col1 col2 col3 col4 col5 col6 col7 $1000;
    set blk_cont blk_cat_01 blk_cat_02 blk_met;
run;

proc sort data=final2output;
    by ord1;
run;

%istartv2(SUFFIX=&suffix.);

%m_u_report(
    table=final2output
    ,lenlist=34#10#11#11#11#11#11
    ,justlist=l#l#c#c#c#c#c
    ,justlist_header=l#l#c#c#c#c#c
    ,nolblist=Y#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N
    ,idlist=Y
    ,idpage=
    ,defcol=col1 col2 col3 col4 col5 col6 col7
    ,blank_after=blank_var
    ,pg=46
    ,pg_byvar=N
    ,pgvar=
);

%istopv2();