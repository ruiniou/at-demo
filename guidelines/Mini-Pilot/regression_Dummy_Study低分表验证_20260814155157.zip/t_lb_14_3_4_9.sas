%let suffix=saf;

proc format;
    value trtfmtc
        1 = 'AZD999(*ESC*)n1 mg/kg'
        2 = 'AZD999(*ESC*)n2 mg/kg'
        3 = 'AZD999(*ESC*)nTotal'
        4 = 'Investigator choice of therapy'
        5 = 'Total'
    ;
run;

%m_u_popn(
    inds=adam.adsl
    ,pop_flag=SAFFL="Y"
    ,trtgrpn=TRT01AN
    ,trtfmtC=trtfmtc
    ,trtlev=1|2|1 2|3|1 2 3
    ,UniqueIDVars=USUBJID
    ,gmacro=saspopb
    ,BigN=Y
    ,nformat=
    ,deBug=N
);

/*@block Bidirectional chemistry CTCAE shift by parameter */
proc sort data=adam.adsl out=adsl_saf(keep=usubjid saffl trt01an);
    by usubjid;
    where saffl='Y' and not missing(trt01an);
run;

proc sort data=adam.adlb out=adlb_saf;
    by usubjid param avalui avalut avaln avisitn adt;
    where saffl='Y' and parcat1='CHEMISTRY' and anl03fl='Y';
run;

data shift_subject;
    merge adlb_saf(in=a) adsl_saf(in=b);
    by usubjid;
    if a and b;

    length pageparam $200 direction $4 baseline_grade $40 max_grade $20;
    if not missing(avalu) then pageparam = strip(param) || ' (' || strip(avalu) || ')';
    else pageparam = strip(param);

    if ablfl='Y' then do;
        if btoxgrl='Grade 4' then do; direction='LOW';  baseline_grade='Grade 4 (low)';  max_grade=''; output; end;
        else if btoxgrl='Grade 3' then do; direction='LOW';  baseline_grade='Grade 3 (low)';  max_grade=''; output; end;
        else if btoxgrl='Grade 2' then do; direction='LOW';  baseline_grade='Grade 2 (low)';  max_grade=''; output; end;
        else if btoxgrl='Grade 1' then do; direction='LOW';  baseline_grade='Grade 1 (low)';  max_grade=''; output; end;

        if btoxgr='Grade 0' then do; direction='LOW';  baseline_grade='Grade 0'; max_grade=''; output; end;
        if btoxgr='Grade 0' then do; direction='HIGH'; baseline_grade='Grade 0'; max_grade=''; output; end;

        if btoxgrh='Grade 1' then do; direction='HIGH'; baseline_grade='Grade 1 (high)'; max_grade=''; output; end;
        else if btoxgrh='Grade 2' then do; direction='HIGH'; baseline_grade='Grade 2 (high)'; max_grade=''; output; end;
        else if btoxgrh='Grade 3' then do; direction='HIGH'; baseline_grade='Grade 3 (high)'; max_grade=''; output; end;
        else if btoxgrh='Grade 4' then do; direction='HIGH'; baseline_grade='Grade 4 (high)'; max_grade=''; output; end;
    end;

    if anl05fl='Y' and not missing(atoxgrl) then do;
        direction='LOW';
        baseline_grade='';
        max_grade=strip(atoxgrl);
        output;
    end;

    if anl04fl='Y' and not missing(atoxgrh) then do;
        direction='HIGH';
        baseline_grade='';
        max_grade=strip(atoxgrh);
        output;
    end;

    keep usubjid trt01an pageparam direction baseline_grade max_grade;
run;

proc sort data=shift_subject;
    by usubjid trt01an pageparam direction;
run;

proc transpose data=shift_subject(where=(baseline_grade ne '')) out=base_wide(drop=_name_) prefix=base_;
    by usubjid trt01an pageparam direction;
    var baseline_grade;
run;

proc transpose data=shift_subject(where=(max_grade ne '')) out=max_wide(drop=_name_) prefix=max_;
    by usubjid trt01an pageparam direction;
    var max_grade;
run;

data shift_pair;
    merge base_wide max_wide;
    by usubjid trt01an pageparam direction;
    length baseline_grade $40 max_grade $20;
    baseline_grade = base_1;
    max_grade      = max_1;
    if not missing(baseline_grade) and not missing(max_grade);
    keep usubjid trt01an pageparam direction baseline_grade max_grade;
run;

/* Expand pooled and overall groups without changing subject-level source treatment. */
data shift_pair_all;
    set shift_pair;
    trtgrp = trt01an; output;
    if trt01an in (1,2) then do; trtgrp = 3; output; end;
    if trt01an in (1,2,3) then do; trtgrp = 5; output; end;
run;

proc sql;
    create table nobs as
    select pageparam, trtgrp, count(distinct usubjid) as nobs
    from shift_pair_all
    group by pageparam, trtgrp;
quit;

proc sql;
    create table counts as
    select pageparam, trtgrp, baseline_grade, max_grade, count(distinct usubjid) as n
    from shift_pair_all
    group by pageparam, trtgrp, baseline_grade, max_grade;
quit;

proc sort data=counts; by pageparam trtgrp baseline_grade max_grade; run;
proc sort data=nobs;   by pageparam trtgrp; run;

/* Build fixed shell row order and column strings. */
data row_template;
    length baseline_grade $40 roword 8;
    infile datalines dlm='|' truncover;
    input roword baseline_grade :$40.;
    datalines;
1|Grade 4 (low)
2|Grade 3 (low)
3|Grade 2 (low)
4|Grade 1 (low)
5|Grade 0
6|Grade 1 (high)
7|Grade 2 (high)
8|Grade 3 (high)
9|Grade 4 (high)
10|Total
;
run;

proc sort data=row_template; by roword; run;

proc sql;
    create table page_trt as
    select distinct a.pageparam, b.trtgrp
    from nobs as a,
         (select 1 as trtgrp from sashelp.class(obs=1)
          union all select 2 from sashelp.class(obs=1)
          union all select 3 from sashelp.class(obs=1)
          union all select 4 from sashelp.class(obs=1)
          union all select 5 from sashelp.class(obs=1)) as b
    order by pageparam, trtgrp;
quit;

data skeleton;
    set page_trt;
    do roword=1 to 10;
        set row_template point=roword;
        output;
    end;
    stop;
run;

proc sql;
    create table cross_full as
    select s.pageparam, s.trtgrp, s.roword, s.baseline_grade,
           n.nobs,
           sum(case when c.max_grade='Grade 0' then c.n else 0 end) as n_g0,
           sum(case when c.max_grade='Grade 1' then c.n else 0 end) as n_g1,
           sum(case when c.max_grade='Grade 2' then c.n else 0 end) as n_g2,
           sum(case when c.max_grade='Grade 3' then c.n else 0 end) as n_g3,
           sum(case when c.max_grade='Grade 4' then c.n else 0 end) as n_g4,
           sum(c.n) as n_total
    from skeleton as s
    left join counts as c
      on s.pageparam=c.pageparam and s.trtgrp=c.trtgrp and s.baseline_grade=c.baseline_grade
    left join nobs as n
      on s.pageparam=n.pageparam and s.trtgrp=n.trtgrp
    group by s.pageparam, s.trtgrp, s.roword, s.baseline_grade, n.nobs
    order by s.pageparam, s.trtgrp, s.roword;
quit;

/* Add total row from all non-total baseline rows within treatment group. */
proc sql;
    create table total_rows as
    select pageparam, trtgrp, 10 as roword, 'Total' as baseline_grade length=40,
           max(nobs) as nobs,
           sum(n_g0) as n_g0,
           sum(n_g1) as n_g1,
           sum(n_g2) as n_g2,
           sum(n_g3) as n_g3,
           sum(n_g4) as n_g4,
           sum(n_total) as n_total
    from cross_full
    where roword between 1 and 9
    group by pageparam, trtgrp;
quit;

proc sql;
    create table detail_rows as
    select * from cross_full where roword between 1 and 9;
quit;

data table_rows;
    set detail_rows total_rows;
run;

proc sort data=table_rows;
    by pageparam trtgrp roword;
run;

/* Render-ready long table with treatment block header row followed by 10 data rows. */
data final2output;
    length col0 $200 col1 $200 col2 $12 col3 $40 col4-col9 $20;
    set table_rows;
    by pageparam trtgrp;
    retain blkord;

    if first.trtgrp then do;
        blkord + 1;
        col0 = pageparam;
        select (trtgrp);
            when (1) col1 = "&&saspopb1";
            when (2) col1 = "&&saspopb2";
            when (3) col1 = "&&saspopb3";
            when (4) col1 = "&&saspopb4";
            when (5) col1 = "&&saspopb5";
            otherwise col1 = '';
        end;
        col2 = coalescec(strip(put(nobs,best.)), '0');
        col3 = '';
        col4 = ''; col5 = ''; col6 = ''; col7 = ''; col8 = ''; col9 = '';
        ord = trtgrp*100;
        blank_var = trtgrp;
        output;
    end;

    col0 = pageparam;
    col1 = '';
    col2 = '';
    col3 = baseline_grade;

    if not missing(nobs) and nobs>0 then do;
        col4 = cats(put(n_g0,best.), ' (', put(100*n_g0/nobs,5.1), ')');
        col5 = cats(put(n_g1,best.), ' (', put(100*n_g1/nobs,5.1), ')');
        col6 = cats(put(n_g2,best.), ' (', put(100*n_g2/nobs,5.1), ')');
        col7 = cats(put(n_g3,best.), ' (', put(100*n_g3/nobs,5.1), ')');
        col8 = cats(put(n_g4,best.), ' (', put(100*n_g4/nobs,5.1), ')');
        if roword=10 then col9 = cats(put(n_total,best.), ' (100)');
        else col9 = cats(put(n_total,best.), ' (', put(100*n_total/nobs,5.1), ')');
    end;
    else do;
        col4 = '0 (0.0)';
        col5 = '0 (0.0)';
        col6 = '0 (0.0)';
        col7 = '0 (0.0)';
        col8 = '0 (0.0)';
        if roword=10 then col9 = '0 (100)';
        else col9 = '0 (0.0)';
    end;

    ord = trtgrp*100 + roword;
    blank_var = trtgrp;
    output;

    keep col0 col1 col2 col3 col4 col5 col6 col7 col8 col9 ord blank_var;
run;

proc sort data=final2output;
    by col0 ord;
run;

data final2qc;
    set final2output;
    keep col:;
run;

proc sql noprint;
    select value into: __oufile
    from tlf.titles
    where upcase(program) = "%upcase(%scan(&_exec_programname., 1, '.'))"
      and upcase(suffix)  = "%upcase(&suffix.)"
      and parm            = "OUTFILE";
quit;

data tlf.&__oufile.;
    set final2qc;
run;

%istartv2(SUFFIX=&suffix.);
%m_u_report(
    table=final2output
    ,lenlist=28#8#18#10#10#10#10#10#10
    ,justlist=l#c#l#c#c#c#c#c#c
    ,justlist_header=l#c#l#c#c#c#c#c#c
    ,nolblist=N#N#N#N#N#N#N#N#N
    ,orderlist=Y#N#N#N#N#N#N#N#N
    ,defcol=col1 col2 col3 ("Maximum on-treatment CTCAE grade" col4 col5 col6 col7 col8 col9)
    ,blank_after=blank_var
    ,pg_byvar=Y
    ,pg=9999
);
%istopv2;